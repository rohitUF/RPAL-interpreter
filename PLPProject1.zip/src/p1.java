/********* PLP FALL 2012, RPAL Parser
 * ROHIT CHAUHAN
 * 8858-9136
 * */


import java.util.ArrayList;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
/**
 *
 * @author Rohit
 */
public class p1 {
    public static void main(String[] args) throws IOException
    {
        if (args.length != 2)
        {
            //System.out.println("Please provide src file name");
            return;
        }
        
        String switches = args[0];
        String srcFile = args[1];
        if (switches.equals("-l"))
        {
            printsource(srcFile);
            return;
        }
        
        else if (switches.equals("-ast"))
        {
            Scanner sc = new Scanner(srcFile);

            ArrayList<Token> tokens = sc.GetAllTokens(srcFile);

            Parser parser = new Parser();
            AST ast = parser.StartParsing(tokens);

            System.out.println(ast.toString());
        }
    }
    
    private static void printsource(String path) throws IOException
    {
        BufferedReader in = new BufferedReader(new FileReader(path)); 
        String text;
        while (in.ready())
        { 
            text = in.readLine(); 
            System.out.println(text); 
        }
        in.close();
    }
}
